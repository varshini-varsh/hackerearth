This Bot helps in generating the grocery list.
