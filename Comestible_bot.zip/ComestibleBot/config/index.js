'use strict';

module.exports = {
        fb :
        {
            pageAccessToken:process.env.pageAccessToken,
            verifyToken:process.env.verifyToken,
            appSecret:process.env.appSecret,
            senderMail:process.env.senderMail,
            pass:process.env.pass,
            OrderAppId:process.env.OrderAppId
        }
    }